"""VPS MCP - Remote VPS management via MCP protocol using SSH key authentication."""

__version__ = "0.1.1"
__author__ = "Lema Core Technologies"
